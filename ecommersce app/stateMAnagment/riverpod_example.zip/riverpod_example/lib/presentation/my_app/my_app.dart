import 'package:flutter/material.dart';
import 'package:riverpod_example/presentation/provider_example/provider_example.dart';
import 'package:riverpod_example/presentation/state_provider_example/state_provider_example.dart';

class MyWidget extends StatefulWidget {
  const MyWidget({super.key});

  @override
  State<MyWidget> createState() => _MyWidgetState();
}

class _MyWidgetState extends State<MyWidget> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          ListTile(
            title: Text("Provider"),
            onTap: () {
             Navigator.of(context).push(MaterialPageRoute(builder: (context)=>ProviderExample()));
            },
          ),
          ListTile(title: Text("State Provider"), onTap: () {
            Navigator.of(context).push(MaterialPageRoute(builder: (context)=>StateProviderExample()));

          }),
          ListTile(title: Text("State Notifier Provider"), onTap: () {

          }),
          ListTile(title: Text("Future Provider"), onTap: () {}),
          ListTile(title: Text("Strem Provider"), onTap: () {}),
          ListTile(title: Text("Chamge Notifier Provider"), onTap: () {}),
          
          ListTile(title: Text("Notify Provider"), onTap: () {}),
          ListTile(title: Text("Async Notify Provider"), onTap: () {}),
        ],
      ),
    );
  }
}
