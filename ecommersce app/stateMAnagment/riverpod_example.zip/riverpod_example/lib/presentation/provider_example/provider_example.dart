import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:riverpod_example/application/controller/const_provider/const_provider.dart';

class ProviderExample extends ConsumerWidget{
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final constantInteger = ref.watch(dateFormatterProvider);

    return Scaffold(body: Text("$constantInteger"));
  }
  
}