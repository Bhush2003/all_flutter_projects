import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:riverpod_example/application/controller/const_provider/const_provider.dart';

class StateProviderExample extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    
    return Scaffold(
      body: Column(
        children: [
          Consumer(
            builder: (BuildContext context, WidgetRef ref, Widget? child) {
              final counter = ref.watch(dateFormatterProvider);
              return Text("$counter");
            },
          ),
          ElevatedButton(
            onPressed: () {
              ref.read(dateFormatterProvider.notifier).state++;
            },
            child: Icon(Icons.add),
          ),
        ],
      ),
    );
  }
}
